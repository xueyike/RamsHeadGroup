//
//  BeerDetailViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/27/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "BeerDetailViewController.h"

@interface BeerDetailViewController ()

@end

@implementation BeerDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Beer Detail";
    _nameLabel.text = [self.beerDetails objectForKey:@"name"];
    _locationLabel.text = [self.beerDetails objectForKey:@"location"];
    _ABVLabel.text = [self.beerDetails objectForKey:@"ABV"];
    _sizeLabel.text = [self.beerDetails objectForKey:@"size"];
    _priceLabel.text = [self.beerDetails objectForKey:@"price"];
    _descriptionView.text  = [self.beerDetails objectForKey:@"description"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
