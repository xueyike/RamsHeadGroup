//
//  IndexTableViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/26/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BeerTypeViewController.h"
#import "MapTableViewController.h"
#import "SearchTableViewController.h"
#import "RewardsViewController.h"
#import "ScanTableViewController.h"
#import "EventsTableViewController.h"

@interface IndexTableViewController : UITableViewController
@property (weak, nonatomic) id delegate;
@property (copy, nonatomic) NSArray *controllers;
@property (copy, nonatomic) NSString *userID;

@end
