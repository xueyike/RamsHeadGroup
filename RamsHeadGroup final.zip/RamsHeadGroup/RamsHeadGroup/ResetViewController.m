//
//  ResetViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/26/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "ResetViewController.h"
#import "IndexTableViewController.h"

@interface ResetViewController ()

@end

@implementation ResetViewController {
    NSMutableData *responseData;
    NSString *ws;
    bool update;
}

//implement protocol methods of NSXMLParser
- (void) parserDidStartDocument:(NSXMLParser *)parser {
    NSLog(@"parserDidStartDocument");
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    if([elementName isEqualToString:@"CreateUserAccountResult"]){
        update = YES;
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    if(update && [string hasPrefix:@"Updated"]){
        self.validateduser = 1;
        NSLog(@"%@", string);
        update = NO;
    }
}

- (void) parserDidEndDocument:(NSXMLParser *)parser {
    NSLog(@"parserDidEndDocument");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"GreenBackground.png"]];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)pressedReset:(id)sender {
    [self.view endEditing:YES];
    self.resetBtn.userInteractionEnabled = NO;
    ws = @"UPDATE";
    
    NSString *envelopeText=
    @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
    "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">\n"
    "  <soap12:Body>\n"
    "    <CreateUserAccount xmlns=\"http://tempuri.org/\">\n"
    "      <UserID>%@</UserID>\n"
    "      <Password>%@</Password>\n"
    "      <UpdateIfExists>true</UpdateIfExists>\n"
    "    </CreateUserAccount>\n"
    "  </soap12:Body>\n"
    "</soap12:Envelope>";
    
    envelopeText = [NSString stringWithFormat:envelopeText,self.usernameInput.text,self.passwordInput.text];
    
    NSData *envelope = [envelopeText dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *url=@"http://www.softwaremerchant.com/OnlineCourse.asmx";
    
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:100.0];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:envelope];
    [request setValue:@"application/soap+xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%lu",[envelope length]] forHTTPHeaderField:@"Content-Length"];
    
    NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    if(connection){
        responseData=[NSMutableData data];
    }
    else
        NSLog(@"NSURLConnection initWithRequest: Failed to return a connection");
    self.resetBtn.userInteractionEnabled = YES;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response

{
    [responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data

{
    [responseData appendData:data];
}


- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error

{
    NSLog(@"connection didFailWithError: %@ %@",
          error.localizedDescription,
          
          [error.userInfo objectForKey:NSURLErrorFailingURLStringErrorKey]);
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection

{
    // extract result using regular expression (only as an example)
    // this is not a good way to do it; should use XPath queries with XML DOM such as GDataXMLDocument
    NSString *responseText = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    
    NSLog(@"%@",responseText);
    [self doParse:responseData];
}

-(void)doParse:(NSData *)data{
    NSXMLParser *nsXmlParser=[[NSXMLParser alloc]initWithData:data];
    nsXmlParser.delegate = self;
    
    [nsXmlParser parse];
    
    if ([ws isEqualToString:@"UPDATE"]){
        if(self.validateduser == 1)
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Reset sucessfully!" message:@"Congratulation! You have reset your password!" delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:@"Continue",nil];
            [alert show];
        }
        else{
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Create a new account" message:[NSString stringWithFormat:@"Created User Account for user '%@'",self.usernameInput.text] delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alert show];
            self.passwordInput.text = @"";
        }
    }
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex;{
    
    // the user clicked "continue"
    if (buttonIndex == 1)
    {
        [self performSegueWithIdentifier:@"showList" sender:self];
    }else{
        self.validateduser = 0;
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    //Get the new view controller using [segue destinationViewController].
    //Pass the selected object to the new view controller.
    
    if([segue.identifier isEqualToString:@"showList"]){
        IndexTableViewController *destination = segue.destinationViewController;
        if ([destination respondsToSelector:@selector(setDelegate:)]) {
            [destination setValue:self forKey:@"delegate"];
        }
        if ([destination respondsToSelector:@selector(setUserID:)]) {
            [destination setValue:self.usernameInput.text forKey:@"userID"];
        }
    }
}
@end
