//
//  SecondLevelViewController.h
//  Nav
//
//  Created by Yike Xue on 6/8/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondLevelViewController : UITableViewController

@property (strong, nonatomic) UIImage *rowImage;
@property (strong, nonatomic) NSString *user;

@end
