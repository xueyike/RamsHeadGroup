//
//  MapTableViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/28/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "MapTableViewController.h"

@interface MapTableViewController ()

@end

@implementation MapTableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Location";
        self.rowImage = [UIImage imageNamed:@"map.jpeg"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"restaurantCell"];
    [self.tableView setSeparatorColor:[UIColor redColor]];
    self.tableView.backgroundColor = [UIColor blackColor];
    
    NSDictionary *res1 = [NSDictionary dictionaryWithObjectsAndKeys:@"Rams Head Tavern Annapolis",@"name",@"33 West Street Annapolis, Maryland 21401",@"address", nil];
    NSDictionary *res2 = [NSDictionary dictionaryWithObjectsAndKeys:@"Rams Head Tavern Savage Mill",@"name",@"8600 Foundry St., Box 2065 Savage, Maryland 20763",@"address", nil];
    NSDictionary *res3 = [NSDictionary dictionaryWithObjectsAndKeys:@"Rams Head Road House",@"name",@"1773 Generals Highway Annapolis MD 21401",@"address", nil];
    NSDictionary *res4 = [NSDictionary dictionaryWithObjectsAndKeys:@"Rams Head Shore House",@"name",@"800 Main Street Stevensville, Maryland 21666",@"address", nil];

    self.restaurantAddress = @[res1,res2,res3,res4];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.restaurantAddress count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"restaurantCell" forIndexPath:indexPath];
    
    // Configure the cell...
    UILabel *label = [ [ UILabel alloc ] initWithFrame: CGRectMake(10.0, 5.0, 355.0 , 30.0) ];
    
    label.text = [self.restaurantAddress[indexPath.row] objectForKey:@"name"];
    
    label.textColor = [ UIColor blackColor ];
    
    label.font = [ UIFont fontWithName: @"Arial" size: 20.0 ];
    
    label.highlightedTextColor = [UIColor yellowColor];
    
    label.backgroundColor = [ UIColor orangeColor ];
    
    [cell addSubview: label];
    
    cell.backgroundColor = [UIColor blackColor];

    return cell;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LocationViewController *controller = [[LocationViewController alloc] init];
    controller.restaurant = self.restaurantAddress[indexPath.row];
    [self.navigationController pushViewController:controller animated:YES];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
