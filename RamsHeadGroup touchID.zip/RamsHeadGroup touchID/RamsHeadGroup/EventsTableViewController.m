//
//  EventsTableViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/29/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "EventsTableViewController.h"

@interface EventsTableViewController ()

@end

@implementation EventsTableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Events";
        self.rowImage = [UIImage imageNamed:@"event.png"];
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    //Make up events:
    NSDictionary *e1 = [NSDictionary dictionaryWithObjectsAndKeys:@"Xmas in July at Rams Head on the 25th!",@"name",@"On July 25th, Rams Head will release Doppelbock for one day only. Each year, a few kegs of Doppelbock are saved for this joyous occasion – and to quench your summertime thirst! Christmas in July is the only time to enjoy this hearty lager until winter rolls around again.",@"discription",@"XMas.png",@"image", nil];
    NSDictionary *e2 = [NSDictionary dictionaryWithObjectsAndKeys:@"Enter to Win Summer Six Pack Ticket!",@"name",@"On July 25th, we’re choosing one winner for our Summer Six Pack Ticket Giveaway! This lucky music fan will win tickets to ANY 6 concerts at one of our three music venues, Pier Six Pavilion, Rams Head Live, and Rams Head On Stage in August and September.",@"discription",@"Six.png",@"image", nil];
    NSDictionary *e3 = [NSDictionary dictionaryWithObjectsAndKeys:@"Instagram share: AMAZON band concert!",@"name",@"The incredible two man band opening for last night. For an hour, a gorgeous light show, mesmerizing beats and nonstop music! Never heard of them before but they've gained a new fan. Join us right at 11 AM! We’ll also have a chance to win a HUGE summer ticket package.",@"discription",@"band.png",@"image", nil];
    NSDictionary *e4 = [NSDictionary dictionaryWithObjectsAndKeys:@"ROCK YOUR BONES 3",@"name",@"COMING UP AT RAMS HEAD LIVE: This is big! On Friday, July 24th, 2015, 24-7 presents. This September, DirtWolf, Spaceboy, Silent Society, You're Too Kind, HalfTone, Jocelyn Faro & The Ragazzi. Get ready to ROCK YOUR BONES with this great local bands! ",@"discription",@"rock.png",@"image", nil];
    NSDictionary *e5 = [NSDictionary dictionaryWithObjectsAndKeys:@"THE INDEPENDENCE EVE MELTDOWN",@"name",@"COMING UP AT RAMS HEAD LIVE: On Friday, July 3rd, 2015, One Koast presents. Survival Of The Sickest, From Nothing, Cryptic Matter, The Electric Prophets, Summer's End, Sonic Creeps, Treazon, Finger Pistols. Get ready to ROCK YOUR BONES with these great local bands!",@"discription",@"flag.jpg",@"image", nil];
    
    self.events = @[e1,e2,e3,e4,e5];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView setSeparatorColor:[UIColor redColor]];
    self.tableView.backgroundColor = [UIColor blackColor];
    // Uncomment the following line to preserve selection between presentations.
     self.clearsSelectionOnViewWillAppear = YES;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.events count]*2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSDictionary *curDict = self.events[indexPath.row/2];
    CGFloat contentWidth;
    NSString *content;
    if(indexPath.row % 2 == 0){
        cell.backgroundColor = [UIColor brownColor];
        content = [curDict objectForKey:@"name"];
        contentWidth = self.tableView.frame.size.width;
        cell.textLabel.font = [UIFont systemFontOfSize:15];
    }else{
        cell.imageView.image = [UIImage imageNamed:[curDict objectForKey:@"image"]];
        content = [curDict objectForKey:@"discription"];
        contentWidth = self.tableView.frame.size.width - cell.imageView.frame.size.width+15;
        cell.backgroundColor = [UIColor orangeColor];
        cell.textLabel.font = [UIFont systemFontOfSize:12];
    }
    cell.textLabel.textColor = [UIColor whiteColor];

    // calcute necessary size
    CGSize size = [content sizeWithFont:[UIFont systemFontOfSize:12] constrainedToSize:CGSizeMake(contentWidth, 1000) lineBreakMode:UILineBreakModeWordWrap];

    CGRect rect = [cell.textLabel textRectForBounds:cell.textLabel.frame limitedToNumberOfLines:0];

    rect.size = size;

    cell.textLabel.frame = rect;
    
    cell.textLabel.text = content;
    

    cell.textLabel.numberOfLines = 0;


    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Column width
    CGFloat contentWidth = self.tableView.frame.size.width;

    UIFont *font = [UIFont systemFontOfSize:12];
    
    NSDictionary *curDict = self.events[indexPath.row/2];
    NSString *content;
    if(indexPath.row % 2 == 0){
        content = [curDict objectForKey:@"name"];
    }else{
        content = [curDict objectForKey:@"discription"];
    }
    // calculate the necessary minimum height
    CGSize size = [content sizeWithFont:font constrainedToSize:CGSizeMake(contentWidth, 1000) lineBreakMode:UILineBreakModeWordWrap];
    

    return size.height+20;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
