//
//  BeerListViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/27/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BeerTableViewController.h"
#import "SecondLevelViewController.h"
#import "AppDelegate.h"

@class BeerTableViewController;

@interface BeerTypeViewController : SecondLevelViewController <NSXMLParserDelegate>

@property (strong, nonatomic) NSMutableDictionary *beerLists;
@property (strong, nonatomic) NSMutableArray *beerTypeName;

@property (nonatomic,strong) NSManagedObjectContext* managedObjectContext;
@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;

@end
