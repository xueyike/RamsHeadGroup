//
//  MapTableViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/28/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"
#import "LocationViewController.h"

@interface MapTableViewController : SecondLevelViewController

@property (copy, nonatomic) NSArray *restaurantAddress;

@end
