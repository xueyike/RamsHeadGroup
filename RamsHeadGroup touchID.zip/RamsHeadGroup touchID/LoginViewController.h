//
//  LoginViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/26/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IndexTableViewController.h"

@interface LoginViewController : UIViewController <NSXMLParserDelegate, UIAlertViewDelegate>

@property int validateduser;

@property (weak, nonatomic) IBOutlet UITextField *usernameInput;

@property (weak, nonatomic) IBOutlet UITextField *passwordInput;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *registerBtn;

- (IBAction)didEndOnExit:(id)sender;

- (IBAction)pressedLogin:(id)sender;

- (IBAction)pressedRegister:(id)sender;
- (IBAction)authenticateButtonTapped:(id)sender;
@end
