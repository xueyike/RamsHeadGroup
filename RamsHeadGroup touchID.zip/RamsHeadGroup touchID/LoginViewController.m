//
//  LoginViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/26/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "LoginViewController.h"
#import <LocalAuthentication/LocalAuthentication.h>

@interface LoginViewController ()

@end

@implementation LoginViewController {
    NSMutableData *responseData;
    NSString *ws;
    bool check;
    bool create;
    NSString *userID;
    bool touchLogin;
}

//implement protocol methods of NSXMLParser
- (void) parserDidStartDocument:(NSXMLParser *)parser {
    NSLog(@"parserDidStartDocument");
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    if ([elementName isEqualToString:@"IsUserValidResult"]){
        check = YES;
    }else if([elementName isEqualToString:@"CreateUserAccountResult"]){
        create = YES;
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    if(check && [string isEqualToString:@"1"]){
        self.validateduser = 1;
        NSLog(@"found %@", string);
        check = NO;
    }else if(create && [string hasPrefix:@"Created"]){
        self.validateduser = 1;
        NSLog(@"%@", string);
        create = NO;
    }
}

- (void) parserDidEndDocument:(NSXMLParser *)parser {
    NSLog(@"parserDidEndDocument");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"GreenBackground.png"]];
    // Do any additional setup after loading the view.
    self.validateduser = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)didEndOnExit:(id)sender {
    [self resignFirstResponder];
}

- (IBAction)pressedLogin:(id)sender {
    [self.view endEditing:YES];
    self.loginBtn.userInteractionEnabled = NO;
    ws = @"LOGIN";
    touchLogin = false;
    
    NSString *envelopeText=
    @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
    "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">\n"
    "  <soap12:Body>\n"
    "    <IsUserValid xmlns=\"http://tempuri.org/\">\n"
    "      <UserID>%@</UserID>\n"
    "      <Password>%@</Password>\n"
    "    </IsUserValid>\n"
    "  </soap12:Body>\n"
    "</soap12:Envelope>";
    
    userID = self.usernameInput.text;
    envelopeText = [NSString stringWithFormat:envelopeText,userID,self.passwordInput.text];
    
    NSData *envelope = [envelopeText dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *url=@"http://www.softwaremerchant.com/OnlineCourse.asmx";
    
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:envelope];
    [request setValue:@"application/soap+xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%d",[envelope length]] forHTTPHeaderField:@"Content-Length"];
    
    NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    if(connection){
        responseData=[NSMutableData data];
    }
    else
        NSLog(@"NSURLConnection initWithRequest: Failed to return a connection");
    self.loginBtn.userInteractionEnabled = YES;
}



- (IBAction)pressedRegister:(id)sender {
    [self.view endEditing:YES];
    self.registerBtn.userInteractionEnabled = NO;
    ws = @"Register";
    touchLogin = false;
    
    NSString *envelopeText=
    @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
    "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">\n"
    "  <soap12:Body>\n"
    "    <CreateUserAccount xmlns=\"http://tempuri.org/\">\n"
    "      <UserID>%@</UserID>\n"
    "      <Password>%@</Password>\n"
    "      <UpdateIfExists>false</UpdateIfExists>\n"
    "    </CreateUserAccount>\n"
    "  </soap12:Body>\n"
    "</soap12:Envelope>";
    
    userID = self.usernameInput.text;
    envelopeText = [NSString stringWithFormat:envelopeText, userID,self.passwordInput.text];
    
    NSData *envelope = [envelopeText dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString *url=@"http://www.softwaremerchant.com/OnlineCourse.asmx";
    
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:envelope];
    [request setValue:@"application/soap+xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"%d",[envelope length]] forHTTPHeaderField:@"Content-Length"];
    
    NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    if(connection){
        responseData=[NSMutableData data];
    }
    else
        NSLog(@"NSURLConnection initWithRequest: Failed to return a connection");
    self.registerBtn.userInteractionEnabled = YES;
}

- (IBAction)authenticateButtonTapped:(id)sender {
    touchLogin = true;
    LAContext *context = [[LAContext alloc] init];
    
    NSError *error = nil;
    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics
                localizedReason:@"Are you the device owner?"
                          reply:^(BOOL success, NSError *error) {
                              
                              if (error) {
                                  dispatch_async (dispatch_get_main_queue(), ^{
                                      //AlertView Code
                                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                      message:@"There was a problem verifying your identity."
                                                                                     delegate:self
                                                                            cancelButtonTitle:@"Ok"
                                                                            otherButtonTitles:nil];
                                      [alert show];
                                  });
                                  
                                  return;
                              }
                              
                              if (success) {
                                  dispatch_async (dispatch_get_main_queue(), ^{
                                      //AlertView Code
                                      [self.view endEditing:YES];
                                      self.loginBtn.userInteractionEnabled = NO;
                                      ws = @"LOGIN";
                                      
                                      NSString *envelopeText=
                                      @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                                      "<soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">\n"
                                      "  <soap12:Body>\n"
                                      "    <IsUserValid xmlns=\"http://tempuri.org/\">\n"
                                      "      <UserID>%@</UserID>\n"
                                      "      <Password>%@</Password>\n"
                                      "    </IsUserValid>\n"
                                      "  </soap12:Body>\n"
                                      "</soap12:Envelope>";
                                      //default user info
                                      
                                      NSString *theUserID = [[NSUserDefaults standardUserDefaults] stringForKey:@"UserID"];
                                      NSString *thePsw = [[NSUserDefaults standardUserDefaults] stringForKey:@"Password"];
                                      envelopeText = [NSString stringWithFormat:envelopeText, theUserID, thePsw];
                                      userID = theUserID;
                                      NSData *envelope = [envelopeText dataUsingEncoding:NSUTF8StringEncoding];
                                      
                                      NSString *url=@"http://www.softwaremerchant.com/OnlineCourse.asmx";
                                      
                                      NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
                                      [request setHTTPMethod:@"POST"];
                                      [request setHTTPBody:envelope];
                                      [request setValue:@"application/soap+xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
                                      [request setValue:[NSString stringWithFormat:@"%d",[envelope length]] forHTTPHeaderField:@"Content-Length"];
                                      
                                      NSURLConnection *connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
                                      
                                      if(connection){
                                          responseData=[NSMutableData data];
                                      }
                                      else
                                          NSLog(@"NSURLConnection initWithRequest: Failed to return a connection");
                                      self.loginBtn.userInteractionEnabled = YES;
                                  });
                                  
                              } else {
                                  dispatch_async (dispatch_get_main_queue(), ^{
                                      //AlertView Code
                                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                                      message:@"You are not the device owner."
                                                                                     delegate:self
                                                                            cancelButtonTitle:@"Ok"
                                                                            otherButtonTitles:nil];
                                      [alert show];
                                  });
                                  
                              }
                              
                          }];
        
    } else {
        dispatch_async (dispatch_get_main_queue(), ^{
            //AlertView Code
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:@"Your device cannot authenticate using TouchID."
                                                           delegate:self
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
        });
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response

{
    [responseData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data

{
    [responseData appendData:data];
}


- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error

{
    NSLog(@"connection didFailWithError: %@ %@",
          error.localizedDescription,
          
          [error.userInfo objectForKey:NSURLErrorFailingURLStringErrorKey]);
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection

{
    // extract result using regular expression (only as an example)
    // this is not a good way to do it; should use XPath queries with XML DOM such as GDataXMLDocument
    NSString *responseText = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    
    NSLog(@"%@",responseText);
    [self doParse:responseData];
}

-(void)doParse:(NSData *)data{
    NSXMLParser *nsXmlParser=[[NSXMLParser alloc]initWithData:data];
    nsXmlParser.delegate = self;
    
    [nsXmlParser parse];
    
    if ([ws isEqualToString:@"LOGIN"]){
        if(self.validateduser == 1)
        {
            if(!touchLogin){
                userID = self.usernameInput.text;
                [[NSUserDefaults standardUserDefaults] setObject:userID forKey:@"UserID"];
                [[NSUserDefaults standardUserDefaults] setObject:self.passwordInput.text forKey:@"Password"];
                [[NSUserDefaults standardUserDefaults]synchronize];
            }
            
            dispatch_async (dispatch_get_main_queue(), ^{
                //AlertView Code
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Login sucessfully!" message:@"Congratulation! You have login in!" delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:@"Continue",nil];
                [alert show];
            });

        }
        else{
            self.validateduser = 0;
            dispatch_async (dispatch_get_main_queue(), ^{
                //AlertView Code
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Incorrect Password" message:@"This password is incorrect" delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
                [alert show];
                self.passwordInput.text = @"";
            });
            
        }
    }else if([ws isEqualToString:@"Register"]){
        if(self.validateduser == 1)
        {
            userID = self.usernameInput.text;
            [[NSUserDefaults standardUserDefaults] setObject:userID forKey:@"UserID"];
            [[NSUserDefaults standardUserDefaults] setObject:self.passwordInput.text forKey:@"Password"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            dispatch_async (dispatch_get_main_queue(), ^{
                //AlertView Code
                NSString *user = userID;
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Register success" message:[NSString stringWithFormat:@"Created User Account for user '%@'",user] delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:@"Continue",nil];
                [alert show];
            });
            
        }else{
            dispatch_async (dispatch_get_main_queue(), ^{
                //AlertView Code
                NSString *user = userID;
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Register fail" message:[NSString stringWithFormat:@"User Account '%@' already exists.",user] delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
                [alert show];
            });
            
        }
        
    }
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex;{
    
    // the user clicked "continue"
    if (buttonIndex == 1)
    {
        [self performSegueWithIdentifier:@"showList" sender:self];
    }else{
        self.validateduser = 0;
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    //Get the new view controller using [segue destinationViewController].
    //Pass the selected object to the new view controller.

    if([segue.identifier isEqualToString:@"showList"]){
        IndexTableViewController *destination = segue.destinationViewController;
        if ([destination respondsToSelector:@selector(setDelegate:)]) {
            [destination setValue:self forKey:@"delegate"];
        }
        if ([destination respondsToSelector:@selector(setUserID:)]) {
            [destination setValue:userID forKey:@"userID"];
        }
    }
}
@end
