//
//  BeerInfo.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 7/1/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "BeerTypesInfo.h"

@class NSManagedObject;

@interface BeerInfo : NSManagedObject

@property (nonatomic, retain) NSString * beerName;
@property (nonatomic, retain) NSString * beerLocation;
@property (nonatomic, retain) NSString * beerABV;
@property (nonatomic, retain) NSString * beerSize;
@property (nonatomic, retain) NSString * beerPrice;
@property (nonatomic, retain) NSString * beerDescription;
@property (nonatomic, retain) NSString * beerType;
@property (nonatomic, retain) BeerTypesInfo *type;

@end
