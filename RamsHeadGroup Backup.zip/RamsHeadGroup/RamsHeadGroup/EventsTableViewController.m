//
//  EventsTableViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/29/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "EventsTableViewController.h"

@interface EventsTableViewController ()

@end

@implementation EventsTableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Events";
        self.rowImage = [UIImage imageNamed:@"event.png"];
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    //Make up events:
    NSDictionary *e1 = [NSDictionary dictionaryWithObjectsAndKeys:@"Xmas in July at Rams Head on the 25th!",@"name",@"On July 25th, Rams Head will release Doppelbock for one day only. Each year, a few kegs of Doppelbock are saved for this joyous occasion – and to quench your summertime thirst! Christmas in July is the only time to enjoy this hearty lager until winter rolls around again.",@"discription",@"XMas.png",@"image", nil];
    NSDictionary *e2 = [NSDictionary dictionaryWithObjectsAndKeys:@"Enter to Win Summer Six Pack Ticket!",@"name",@"THIS IS BIG! On July 25th, we’re choosing one winner for our Summer Six Pack Ticket Giveaway! This lucky music fan will win tickets to ANY 6 concerts at one of our three music venues, Pier Six Pavilion, Rams Head Live, and Rams Head On Stage in the months of August and September 2015.",@"discription",@"Six.png",@"image", nil];
    NSDictionary *e3 = [NSDictionary dictionaryWithObjectsAndKeys:@"Instagram share: AMAZON band concert!",@"name",@"The incredible two man band opening for last night. Mesmerizing beats, a gorgeous light show, and nonstop music for an hour! Never heard of them before but they've gained a new fan. Join us right at 11 AM! We’ll also have live music and a chance to win a HUGE summer ticket package.",@"discription",@"band.png",@"image", nil];
    
        
    self.events = @[e1,e2,e3];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView setSeparatorColor:[UIColor redColor]];
    self.tableView.backgroundColor = [UIColor blackColor];
    // Uncomment the following line to preserve selection between presentations.
     self.clearsSelectionOnViewWillAppear = YES;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.events count]*2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    NSDictionary *curDict = self.events[indexPath.row/2];
    CGFloat contentWidth;
    NSString *content;
    if(indexPath.row % 2 == 0){
        cell.backgroundColor = [UIColor brownColor];
        content = [curDict objectForKey:@"name"];
        contentWidth = self.tableView.frame.size.width;
        cell.textLabel.font = [UIFont systemFontOfSize:15];
    }else{
        cell.imageView.image = [UIImage imageNamed:[curDict objectForKey:@"image"]];
        content = [curDict objectForKey:@"discription"];
        contentWidth = self.tableView.frame.size.width - cell.imageView.frame.size.width;
        cell.backgroundColor = [UIColor orangeColor];
        cell.textLabel.font = [UIFont systemFontOfSize:12];
    }
    cell.textLabel.textColor = [UIColor whiteColor];

    // calcute necessary size
    CGSize size = [content sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(contentWidth, 1000) lineBreakMode:UILineBreakModeWordWrap];

    CGRect rect = [cell.textLabel textRectForBounds:cell.textLabel.frame limitedToNumberOfLines:0];

    rect.size = size;

    cell.textLabel.frame = rect;
    
    cell.textLabel.text = content;
    

    cell.textLabel.numberOfLines = 0;


    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // 列寬
    CGFloat contentWidth = self.tableView.frame.size.width;
    // 用何種字體進行顯示
    UIFont *font = [UIFont systemFontOfSize:15];
    
    NSDictionary *curDict = self.events[indexPath.row/2];
    NSString *content;
    if(indexPath.row % 2 == 0){
        content = [curDict objectForKey:@"name"];
    }else{
        content = [curDict objectForKey:@"discription"];
    }
    // 計算出顯示完內容需要的最小尺寸
    CGSize size = [content sizeWithFont:font constrainedToSize:CGSizeMake(contentWidth, 1000) lineBreakMode:UILineBreakModeWordWrap];
    
    // 這裏返回需要的高度
    return size.height+10;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
