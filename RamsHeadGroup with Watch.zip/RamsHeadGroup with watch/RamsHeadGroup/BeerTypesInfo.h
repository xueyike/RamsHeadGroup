//
//  BeerTypesInfo.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 7/1/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class BeerInfo;

@interface BeerTypesInfo : NSManagedObject

@property (nonatomic, retain) NSString * typeName;
@property (nonatomic, retain) NSString * typeID;
@property (nonatomic, retain) NSSet *beers;
@end

@interface BeerTypesInfo (CoreDataGeneratedAccessors)

- (void)addBeersObject:(BeerInfo *)value;
- (void)removeBeersObject:(BeerInfo *)value;
- (void)addBeers:(NSSet *)values;
- (void)removeBeers:(NSSet *)values;

@end
