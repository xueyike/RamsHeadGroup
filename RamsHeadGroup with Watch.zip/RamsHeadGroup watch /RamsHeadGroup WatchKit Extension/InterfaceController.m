//
//  InterfaceController.m
//  RamsHeadGroup WatchKit Extension
//
//  Created by Yike Xue on 9/3/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "InterfaceController.h"

@interface InterfaceController()

@end


@implementation InterfaceController

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    NSLog(@"start watch");
    // Configure interface objects here.
    // Initialize the wormhole
    self.wormhole = [[MMWormhole alloc] initWithApplicationGroupIdentifier:@"group.com.softwaremerchant.training.RamsHeadGroup"
                                                         optionalDirectory:@"wormhole"];
    
//    // Obtain an initial value for the selection message from the wormhole
//    id messageObject = [self.wormhole messageWithIdentifier:@"selection"];
//    NSString *string = [messageObject valueForKey:@"selectionString"];
//    NSLog(@"%@",string);
//    if (string != nil) {
//        [self.selectionLabel setText:[self translateLabelText:string]];
//    }else{
//        [self.selectionLabel setText:@"Please login!"];
//    }
    
    // Listen for changes to the selection message. The selection message contains a string value
    // identified by the selectionString key. Note that the type of the key is included in the
    // name of the key.
    [self.wormhole listenForMessageWithIdentifier:@"selection" listener:^(id messageObject) {
        NSString *string = [messageObject valueForKey:@"selectionString"];
        NSLog(@"Received message %@!",string);
        if (string != nil) {
            [self.selectionLabel setText:[self translateLabelText:string]];
        }else{
            [self.selectionLabel setText:@"Please login!"];
            [self.btn1 setHidden:YES];
            [self.btb2 setHidden:YES];
            [self.btn3 setHidden:YES];
        }
    }];
    
}

- (NSString *)translateLabelText: (NSString *)select{
    if([select isEqualToString:@"-1"]){
        NSLog(@"Not login");
        [self.btn1 setHidden:YES];
        [self.btb2 setHidden:YES];
        [self.btn3 setHidden:YES];
        return @"Please login on your iphone";
    }else if([select isEqualToString:@"0"]){
        return @"Please see beer list on your iphone";
    }else if([select isEqualToString:@"1"]){
        return @"The location info is on your iphone";
    }else if([select isEqualToString:@"2"]){
        return @"The live music info is on your iphone";
    }else if([select isEqualToString:@"3"]){
        return @"Points:";
    }else if([select isEqualToString:@"4"]){
        return @"Please scan your bill on your iphone";
    }else if([select isEqualToString:@"5"]){
        return @"Xmas in July at Rams Head on the 25th!";
    }else{
        [self.btn1 setHidden:NO];
        [self.btb2 setHidden:NO];
        [self.btn3 setHidden:NO];
        return select;
    }
}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [super willActivate];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (IBAction)selectOne {
//    NSIndexPath *rowPath = [NSIndexPath indexPathForRow:0 inSection:0];
    NSString *rowStr = @"0";
    [self.wormhole passMessageObject:@{@"buttonString" : rowStr} identifier:@"button"];
    [self.selectionLabel setText:[self translateLabelText:rowStr]];
    NSLog(@"Send button message 0");
}
- (IBAction)selectThree {
    NSString *rowStr = @"3";
    [self.wormhole passMessageObject:@{@"buttonString" : rowStr} identifier:@"button"];
    [self.selectionLabel setText:[self translateLabelText:rowStr]];

    NSLog(@"Send button message 3");
}
- (IBAction)selectFive {
    NSString *rowStr = @"5";
    [self.wormhole passMessageObject:@{@"buttonString" : rowStr} identifier:@"button"];
    [self.selectionLabel setText:[self translateLabelText:rowStr]];

    NSLog(@"Send button message 5");

}
@end



