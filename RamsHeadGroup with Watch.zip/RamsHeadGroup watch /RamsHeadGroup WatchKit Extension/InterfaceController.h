//
//  InterfaceController.h
//  RamsHeadGroup WatchKit Extension
//
//  Created by Yike Xue on 9/3/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import <MMWormhole.h>

@interface InterfaceController : WKInterfaceController

@property (nonatomic, strong) MMWormhole *wormhole;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *selectionLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceButton *btn1;
@property (weak, nonatomic) IBOutlet WKInterfaceButton *btb2;
@property (weak, nonatomic) IBOutlet WKInterfaceButton *btn3;

@end
