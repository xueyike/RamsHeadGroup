//
//  BeerTypesInfo.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 7/1/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "BeerTypesInfo.h"
#import "BeerInfo.h"


@implementation BeerTypesInfo

@dynamic typeName;
@dynamic typeID;
@dynamic beers;

@end
