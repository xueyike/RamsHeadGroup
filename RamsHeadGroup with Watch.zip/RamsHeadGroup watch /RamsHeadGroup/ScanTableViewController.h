//
//  ScanTableViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/30/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"
#import "ZBarSDK.h"

@class ZBarReaderView;
@class ScanTableViewController;

@interface ScanTableViewController : SecondLevelViewController <ZBarReaderDelegate, NSXMLParserDelegate>

@property (retain, nonatomic) NSMutableArray *billCode;

@end
