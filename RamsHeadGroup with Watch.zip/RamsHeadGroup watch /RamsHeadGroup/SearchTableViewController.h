//
//  SearchTableViewController.h
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/29/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"
@class SearchTableViewController;

@interface SearchTableViewController : SecondLevelViewController

@property (copy, nonatomic) NSArray *searchName;

@end
