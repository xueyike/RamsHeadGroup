//
//  IndexTableViewController.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 6/26/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "IndexTableViewController.h"
#import "SecondLevelViewController.h"


@implementation IndexTableViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.clearsSelectionOnViewWillAppear = YES;
    self.userID = self.navigationController.title;
    self.title = @"Menu";
    [self.tableView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"GreenBackground.png"]]];
    self.controllers = @[
                         [[BeerTypeViewController alloc] init],
                         [[MapTableViewController alloc] init],
                         [[SearchTableViewController alloc] init],
                        [[RewardsViewController alloc] init],
                         [[ScanTableViewController alloc] init],
                         [[EventsTableViewController alloc] init]
                         ];
    
//    self.controllers = @[@"Beer List",@"View On Map",@"Find Transportation",@"Live Music Search",@"Rewards",@"Redeem Points",@"Events"];
    
    // Initialize the wormhole
    self.wormhole = [[MMWormhole alloc] initWithApplicationGroupIdentifier:@"group.com.softwaremerchant.training.RamsHeadGroup"
                                                         optionalDirectory:@"wormhole"];
    
//    // Obtain an initial value for the selection message from the wormhole
//    id messageObject = [self.wormhole messageWithIdentifier:@"button"];
//    NSString *row = [messageObject valueForKey:@"buttonString"];
//    if (row != nil && ![row isEqualToString:@"-1"]) {
//        NSIndexPath *rowPath = [NSIndexPath indexPathForRow:[row intValue] inSection:0];
//        [self tableView:self.tableView didSelectRowAtIndexPath:rowPath];
//    }
    
    // Listen for changes to the selection message. The selection message contains a string value
    // identified by the selectionString key. Note that the type of the key is included in the
    // name of the key.
    [self.wormhole listenForMessageWithIdentifier:@"button" listener:^(id messageObject) {
        NSString *row = [messageObject valueForKey:@"buttonString"];
        
        if (row != nil && ![row isEqualToString:@"-1"]) {
            NSIndexPath *rowPath = [NSIndexPath indexPathForRow:[row intValue] inSection:0];
            [self tableView:self.tableView didSelectRowAtIndexPath:rowPath];
        }
    }];
    
    [self.wormhole passMessageObject:@{@"selectionString" : [NSString stringWithFormat:@"Hello, %@",self.userID]} identifier:@"selection"];
}

- (void)viewWillAppear:(BOOL)animated{
//    [self.wormhole passMessageObject:@{@"selectionString" : [NSString stringWithFormat:@"Hello, %@",self.userID]} identifier:@"selection"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.controllers count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    SecondLevelViewController *controller = self.controllers[indexPath.row];
    cell.textLabel.text = controller.title;
    cell.imageView.image = controller.rowImage;
    // Configure the cell...
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.font = [UIFont boldSystemFontOfSize:38.00];
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SecondLevelViewController *controller = self.controllers[indexPath.row];
    controller.user = [NSString stringWithFormat:@"%@",self.userID];
    if(![self.navigationController.topViewController isKindOfClass:[SecondLevelViewController class]]) {
        [self.wormhole passMessageObject:@{@"selectionString" : [NSString stringWithFormat:@"%hd",(short)indexPath.row]} identifier:@"selection"];
        [self.navigationController pushViewController:controller animated:YES];
    }else{
        [self.navigationController popToRootViewControllerAnimated:YES];
        [self.wormhole passMessageObject:@{@"selectionString" : [NSString stringWithFormat:@"%hd",(short)indexPath.row]} identifier:@"selection"];
        [self.navigationController pushViewController:controller animated:YES];
    }
}
@end
