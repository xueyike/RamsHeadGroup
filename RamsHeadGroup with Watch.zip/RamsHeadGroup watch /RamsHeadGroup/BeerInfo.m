//
//  BeerInfo.m
//  RamsHeadGroup
//
//  Created by Yike Xue on 7/1/15.
//  Copyright (c) 2015 Yike Xue. All rights reserved.
//

#import "BeerInfo.h"


@implementation BeerInfo

@dynamic beerName;
@dynamic beerLocation;
@dynamic beerABV;
@dynamic beerSize;
@dynamic beerPrice;
@dynamic beerDescription;
@dynamic beerType;
@dynamic type;

@end
